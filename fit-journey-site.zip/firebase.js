import { initializeApp } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";

const firebaseConfig = {
    apiKey: "AIzaSyBn7285yLxxma2ygeGzRyw1kgdq2kKEpVg",
    authDomain: "fit-journey-cd5f6.firebaseapp.com",
    projectId: "fit-journey-cd5f6",
    storageBucket: "fit-journey-cd5f6.firebasestorage.app",
    messagingSenderId: "121793570416",
    appId: "1:121793570416:web:82967707ea6f17a33336b5",
    measurementId: "G-LRCRQGBHHH"
};

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
